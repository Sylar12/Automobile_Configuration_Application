//Name: Pinchaow
//Andrew ID: pinchaow
package driver;

import java.io.FileNotFoundException;
import java.io.IOException;

public class ClientDriver {
	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException{
		/**
		 * Unit1: test for basic car configuration application
		 */
		//Driver_U1 driver_u1 = new Driver_U1();
		//driver_u1.startTest();
		
		/**
		 * Unit2: test for customized exception handling
		 */
		//Driver_U2 driver_u2 = new Driver_U2();
		//driver_u2.startTest();
		
		/**
		 * Unit3: Test for Multi-Threading
		 */
		//Driver_U3 driver_u3 = new Driver_U3();
		//driver_u3.startTest();
		
		/**
		 * Unit4 & 5: Sockets communication - client side
		 * Enable server-client socket connection
		 */
		Driver_U4 driver_u4 = new Driver_U4();
		driver_u4.startTest();
		
	}
}