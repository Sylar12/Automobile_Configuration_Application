package exception;

import java.util.Scanner;

public class AutomobileExceptions {
	
	public static class MissFileName extends Exception{
		public MissFileName(String msg){
			super(msg);
		}
	}
	
	public static class MissMake extends Exception{
		public MissMake(String msg){
			super(msg);
		}
		public String getMake() {
			Scanner userInputScanner = new Scanner(System.in);
			System.out.print("\nPlease enter the 'Make' value: ");
			return userInputScanner.nextLine();
		}
	}
	
	public static class MissModel extends Exception{
		public MissModel(String msg){
			super(msg);
		}
		public String getModel() {
			Scanner userInputScanner = new Scanner(System.in);
			System.out.print("\nPlease enter the 'Model' value: ");
			return userInputScanner.nextLine();
		}
	}
	
	public static class MissBasePrice extends Exception{
		public MissBasePrice(String msg){
			super(msg);
		}
		public String getModel() {
			Scanner userInputScanner = new Scanner(System.in);
			System.out.print("\nPlease enter the 'Base Price' value: ");
			return userInputScanner.nextLine();
		}
	}
	
	public static class MissOptionPrice extends Exception{
		public MissOptionPrice(String msg) {
			super(msg);
		}
		public String getOptionPrice() {
			Scanner userInputScanner = new Scanner(System.in);
			System.out.print("\nPlease enter the 'Option Price' value: ");
			return userInputScanner.nextLine();
		}
	}
}
