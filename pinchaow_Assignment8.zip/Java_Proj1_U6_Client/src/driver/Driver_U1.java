package driver;

import java.io.IOException;

import adapter.BuildAuto;
import model.Automobile;
import util.FileIO;

public class Driver_U1 {
	public void startTest() throws IOException, ClassNotFoundException {
		BuildAuto fordZTW = new BuildAuto();
		String modelName = fordZTW.buildAuto("AutomobileOptions.txt", "textFile");
		fordZTW.printAuto(modelName);
		
		FileIO fileIOser = new FileIO();
		fileIOser.serializeAuto(fordZTW, "auto.ser");
		BuildAuto newFordZTW = fileIOser.deserializeAuto("auto.ser");
		String modelNameNew = fordZTW.buildAuto("AutomobileOptions.txt", "textFile");

		//Print new attributes
		System.out.println("//Print new attributes");
		newFordZTW.printAuto(modelNameNew);
	}

}
