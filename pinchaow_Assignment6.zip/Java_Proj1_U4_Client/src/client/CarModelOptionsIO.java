package client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class CarModelOptionsIO {
	public Properties readPropertyFile(){
		System.out.println("Please enter the name of the properity file containing automobile information:");
		Scanner input_sc = new Scanner(System.in);
		String fileName = input_sc.nextLine();

		FileInputStream in = null;
		try {
			in = new FileInputStream(fileName);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Properties props = new Properties();
		try {
			props.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return props;
	}
}
