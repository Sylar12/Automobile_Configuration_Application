//Name: Pinchao Wang
//Andrew ID: pinchaow

package driver;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;

import model.Automobile;
import util.FileIO;

import adapter.BuildAuto;

public class Driver {
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		System.out.println("## Test: Part A ##");
		
		// Test Case 1: To create and print an Auto instance through CreateAuto interface.
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Test Case 1: To create and print an Auto instance through CreateAuto interface.");
		BuildAuto testAutoShop = new BuildAuto();
		testAutoShop.buildAuto("testAutoShop1", "AutomobileOptions.txt");
		testAutoShop.printAuto("testAutoShop1");

		// Test Case 2: To update one of OptionSet’s name or Option Price for the Auto instance created in previous step.
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("Test Case 2: To update one of OptionSet’s name or Option Price for the Auto instance created in previous step.");
		System.out.println("[Update] Option Set Name 'Side Impact Air Bags' --> 'Front Impact Air Bags'");
		System.out.println("[Update] Option Set 'Power Moonroof' Option 'selected - price' '595.0' --> $1234.0");
		testAutoShop.updateOptionSetName("testAutoShop1", "Side Impact Air Bags", "Front Impact Air Bags");
		testAutoShop.updateOptionPrice("testAutoShop1", "Power Moonroof", "selected", 1234);
		System.out.println("");
		testAutoShop.printAuto("testAutoShop1");
		
		// Test Case 3: Exception - Missing filename or wrong filename
		// Test Case 4: Exception - Missing OptionSet data (Make)
		// Test Case 5: Exception - Missing OptionSet data (Model)
		// Test Case 6: Exception - Missing price for Automobile in Text file
		// Test Case 7: Exception - Missing option data
		String text[] = new String[5];
		text[0] = "Test Case 3: Exception - Missing filename or wrong filename";
		text[1] = "Test Case 4: Exception - Missing OptionSet data (Make)";
		text[2]	= "Test Case 5: Exception - Missing OptionSet data (Model)";
		text[3] = "Test Case 6: Exception - Missing price for Automobile in Text file";
		text[4] = "Test Case 7: Exception - Missing option data";
		
		String fileName[] = new String[5];
		fileName[0] = "";
		fileName[1] = "AutomobileOptions_missing_Make.txt";
		fileName[2] = "AutomobileOptions_missing_Model.txt";
		fileName[3] = "AutomobileOptions_missing_BasePrice.txt";
		fileName[4] = "AutomobileOptions_missing_OptionValue.txt";
		
		for (int i=0; i<5; i++) {
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println(text[i]);
			String shopName = "testAutoShop" + String.valueOf(i+2);
			testAutoShop.buildAuto(shopName, fileName[i]);
			System.out.println();
			testAutoShop.printAuto(shopName);
		}

		System.out.println("\n## Test: Part B ##");
	    // Put auto 1 - Ford to the map
		testAutoShop.buildAuto("Ford", "AutomobileOptions.txt");
	    
	    // Put auto 2 - Toyota to the map
		testAutoShop.buildAuto("Toyota", "ToyotaOptions.txt");
		
		testAutoShop.setOptionChoice("Ford", "Power Moonroof", "selected");
		System.out.println("Print selected option:");
		System.out.println(testAutoShop.getOptionChoice("Ford", "Power Moonroof"));
		System.out.println("Print selected option price:");
		System.out.println(testAutoShop.getOptionChoicePrice("Ford", "Power Moonroof"));
		
		System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		System.out.println("**Test of Serialization**");
		FileIO serDe = new FileIO();
		serDe.serializeAuto(testAutoShop, "testAutoShop.ser");
		BuildAuto loadedAutoShop = serDe.deserializeAuto("testAutoShop.ser");
		System.out.println("Print Toyota Options:");
		loadedAutoShop.printAuto("Toyota");
	}
}
