package util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import model.Automotive;

public class FileIO {
	// Read data from a text file
	public Automotive buildAutoObject(String fileName, Automotive al) {
		try{
			FileReader file = new FileReader(fileName);
			BufferedReader buff = new BufferedReader(file);
			
			Automotive automobile = al;
			int opsetIndex = 0;
			boolean eof = false;
			while (!eof) {
				String line = buff.readLine();
				
				if (line == null){
					eof = true;
					break;
				}
				
				// Set OptionSet
				String[] opsetSplit = line.split(":");
				String opsetName = opsetSplit[0];
				String[] opt = opsetSplit[1].split(";");
				int optionSize = opt.length;
				automobile.setOpsetValues(opsetIndex, opsetName, optionSize); 
				
				// Set Option 
				for (int optIndex=0; optIndex<optionSize; optIndex++) {
					String[] optSplit = opt[optIndex].split(",");
					String optName = optSplit[0];
					float optPrice = Float.parseFloat(optSplit[1]);
					automobile.setOptValues(opsetIndex, optIndex, optName, optPrice);
				}
				opsetIndex++;
			}
			buff.close();
		} catch (IOException e) {
			System.out.println("Error -- " + e.toString());
		}
		return al;
	}
	
	// Read a serialized file
	public void serializeAuto(Automotive automobile, String fileName) throws IOException {
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName));
		out.writeObject(automobile);
		out.close();
	}
	
	public Automotive deserializeAuto(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
		Automotive automobile = (Automotive) in.readObject();
		return automobile;
	}
}
