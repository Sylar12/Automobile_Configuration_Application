package server;
import adapter.ProxyAutomobile;
import model.Automobile;

public class BuildCarModelOptions extends ProxyAutomobile implements AutoServer{
	public void buildCarModelOptions(String modelName, Automobile auto) {
		buildCarModelOptions(modelName, auto);
	}

	public String printAllModelNames() {
		return printAllModelNames();
	}

	public Automobile returnSelectedAuto(String modelName) {
		return returnSelectedAuto(modelName);
	}
	
	//
	public void deleteAuto(String modelName){
		deleteAuto(modelName);
	}
}
