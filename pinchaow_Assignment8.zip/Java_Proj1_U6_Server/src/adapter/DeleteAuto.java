package adapter;

public interface DeleteAuto {
	void deleteAuto(String modelName);
}
