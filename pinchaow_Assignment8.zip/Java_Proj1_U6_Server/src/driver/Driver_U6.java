package driver;

import database.DBCreateSchema;
import database.DBCreateTable;
import adapter.BuildAuto;
import adapter.DBBuildAuto;

public class Driver_U6 {
	public void startTest(){
		String serverName = "localhost";
		String portNumber = "3306";
		String dbName = "DBAutomobiles";

		String username = "root";
		String password = "";
		
		System.out.println("##Unit 6 Test for JDBC and Database##");
		System.out.println("========================");
		
		
		// Create database schema by reading sql from file
		DBCreateSchema cs = new DBCreateSchema(serverName, portNumber, username, password);
		cs.createSchemaFromFile("sql/create_schema.sql");
		System.out.println("\n");
		
		
		// Create database tables by reading sql from file
		DBCreateTable ct = new DBCreateTable(serverName, portNumber, dbName, username, password);
		ct.createTableFromFile("sql/model.sql");
		ct.createTableFromFile("sql/opset.sql");
		ct.createTableFromFile("sql/model_opset.sql");
		ct.createTableFromFile("sql/opt.sql");
		ct.createTableFromFile("sql/opset_opt.sql");
		System.out.println("\n");
		
		/*
		 * Below are the operations in static LishHashMap object and data in DB
		 * All CREATE, DELETE, and UPDATE operation in DB are implemented with interfaces
		 * 
		 * Creating three models ("Pitts", "Prius" and "Focus Wagon ZTW") to the static LinkedHashMap object
		 * Automobile information stored in MySQL database updated accordingly
		 */
		System.out.println("##Test Add Automobiles to LinkedHashMap and DB concurrently. \n");
		DBBuildAuto testAutoShop = new DBBuildAuto();
		String modelName1 = testAutoShop.buildAuto("Pitts.txt");
		String modelName2 = testAutoShop.buildAuto("Prius.txt");
		String modelName3 = testAutoShop.buildAuto("Focus_Wagon_ZTW.txt");
		System.out.println("\nSelect Automobile Model '" + modelName1 +"' to Print for testing:");
		System.out.println("~~~~~~~~Print Automobile Model [" + modelName1 + "]~~~~~~~~");
		testAutoShop.printAuto(modelName1);
		System.out.println("\n");
		
		
		// Deleting one models ("Focus_Wagon_ZTW.txt") from the static LinkedHashMap object
		// Automobile information stored in MySQL database updated accordingly
		System.out.println("##Test Delete Automobiles from LinkedHashMap and DB concurrently. \n");
		testAutoShop.deleteAuto(modelName3);
		System.out.println("\n");
		

		// Updating some option values from the static LinkedHashMap object
		// Automobile information stored in MySQL database updated accordingly
		System.out.println("##Test Update Automobiles in LinkedHashMap and DB concurrently. \n");
		testAutoShop.updateOptionPrice(modelName1, "Color", "Fort Knox Gold Clearcoat Metallic", 1234);
		testAutoShop.updateOptionPrice(modelName1, "Color", "Liquid Grey Clearcoat Metallic", 666);
		testAutoShop.updateOptionPrice(modelName1, "Power Moonroof", "selected", 100);

		System.out.println("~~~~~~~~Print Automobile Model [" + modelName1 + "]~~~~~~~~");
		testAutoShop.printAuto(modelName1);
	}
}
