package model;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashMap;

import model.OptionSet.Option;
import exception.AutoOptionException;

public class Automobile implements Serializable {
	/**
	 * Add generated serial version id
	 */
	private static final long serialVersionUID = 6333467450448737847L;
	private String make;
	private String model;
	private float baseprice;
	private LinkedHashMap<String, OptionSet> opsetList;
	
	// Constructors
	public Automobile(){
		super();
		this.model = null;
		this.baseprice = 0;
		this.opsetList = new LinkedHashMap<String, OptionSet>();
	}

	public Automobile (String n, float price){
		this.model = n;
		this.baseprice = price;
		this.opsetList = new LinkedHashMap<String, OptionSet>();
	}

	// Getters
	public synchronized String getMake() {
		return make;
	}
	
	public synchronized String getModel() {
		return model;
	}
	
	public synchronized float getBaseprice() {
		return baseprice;
	}
	
	public synchronized LinkedHashMap<String, OptionSet> getOpsetList() {
		return opsetList;
	}
	
	public synchronized OptionSet getOpset(String opsetName) {
		return opsetList.get(opsetName);
	}
	
	public synchronized String getOptionChoice(String opsetName){
		return opsetList.get(opsetName).getOptionChoice().getName();
	}
	
	public synchronized float getOptionChoicePrice(String opsetName){
		return opsetList.get(opsetName).getOptionChoice().getPrice();
	}
	
	public synchronized float getTotalPrice(){
		float totalPrice = (float) 0.0;
		Iterator<String> iter = opsetList.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			totalPrice += opsetList.get(key).getOptionChoice().getPrice();
		}
		return totalPrice;
	}
	
	// Finders
	public synchronized OptionSet findOpsetWithName(String opsetName){
		return opsetList.get(opsetName);
	}
	
	public synchronized Option findOptWithName(String optName){
		Iterator<String> iter = opsetList.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			OptionSet optList = opsetList.get(key);
			for (int j=0; j<optList.getOpt().size(); j++){
				if (optList.getOpt().get(j).getName().equals(optName)){
					return optList.getOpt().get(j);
				}
			}
		}
		return null;
	}

	//Setters
	public synchronized void setMake(String make) {
		this.make = make;
	}
	
	public synchronized void setModel(String model) {
		this.model = model;
	}

	public synchronized void setBaseprice(float baseprice) {
		this.baseprice = baseprice;
	}

	public synchronized void setOpsetValues(String opsetName) {
		OptionSet opset = new OptionSet();
		opsetList.put(opsetName, opset);
	}
	
	public void setOptionValues(String opsetName, String name, float price){
		this.opsetList.get(opsetName).getOpt().add(opsetList.get(opsetName).setOptionValues(name, price));
	}
	
	public synchronized void setOptionChoice(String opsetName, String optionName){
		opsetList.get(opsetName).setOptionChoice(optionName);
	}
	
	//Update
	public void updateOpsetName(String opsetName, String newName){
		try{
			if (!opsetList.containsKey(opsetName))
				throw new AutoOptionException("The option set name entered is not found. Please check!" + 
								"\nNo update is made.");
			else {
				opsetList.put(newName, opsetList.get(opsetName));
				opsetList.remove(opsetName);
				System.out.println("Updated!");
			}
		} catch(AutoOptionException e){
			System.out.println(e.getMsg());
		}
	}
	
	public synchronized void updateOpt(String opsetName, String optName, float price){
		try{
			if(!opsetList.containsKey(opsetName))
				throw new AutoOptionException("The option set name entered is not found. Please check!" + 
						"\nNo update is made.");
			else{
				OptionSet OptList = opsetList.get(opsetName);
				boolean optNameExists = false;
				for (int j=0; j<OptList.getOpt().size(); j++){
					if (OptList.getOpt().get(j).getName().equals(optName)){
						OptList.getOpt().get(j).setPrice(price);
						optNameExists = true;
						break;
					}
				}
				if (optNameExists == false) {
					throw new AutoOptionException("The option name entered is not found. Please check!" + 
							"\nNo update is made.");
				}
				else {
					System.out.println("Updated!");
				}
			}
		} catch(AutoOptionException e){
			System.out.println(e.getMsg());
		}
	}
	
	//Delete
	public synchronized void deleteOpset(String opsetmodel){
		opsetList.remove(opsetmodel);
	}
	
	public synchronized void deleteOpt(String opsetName, String optName){
		OptionSet OptList = opsetList.get(opsetName);
		for (int j=0; j<OptList.getOpt().size(); j++){
			if (OptList.getOpt().get(j).getName().equals(optName)){
				OptList.getOpt().remove(j);
				break;
			}
		}
	}
	
	// Print automobile model, base price and options
	public synchronized String toString(){
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("Make: ");
		stringBuffer.append(make);
		stringBuffer.append("\nModel: ");
		stringBuffer.append(model);
		stringBuffer.append("\nBase Price: $");
		stringBuffer.append(baseprice);
		
		
		Iterator<String> iter = opsetList.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			OptionSet optList = opsetList.get(key);
			stringBuffer.append("\n\n");
			stringBuffer.append(key + ":");	
			stringBuffer.append(optList.print());	
		}
		stringBuffer.append("\n" + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		return stringBuffer.toString();
	}
}
