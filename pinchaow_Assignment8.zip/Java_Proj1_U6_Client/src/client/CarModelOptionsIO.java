package client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class CarModelOptionsIO {
	public Properties readPropertyFile(String filename){
		String fileName = filename;
		if(fileName.equalsIgnoreCase("")){
			System.out.println("Please enter the name of property file containing automobile model information:");
			Scanner input_sc = new Scanner(System.in);
			fileName = input_sc.nextLine();
		} 

		boolean toCheck = true;
		FileInputStream in = null;
		while (toCheck) {
			try {
				in = new FileInputStream(fileName);
			} catch (FileNotFoundException e) {
	//			e.printStackTrace();
				Scanner userInputScanner = new Scanner(System.in);
				System.out.print("\nWrong File name, please reenter the Property File name: ");
				fileName = userInputScanner.nextLine();
				continue;
			}
			toCheck = false;
		}
		
		Properties props = new Properties();
		try {
			props.load(in);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return props;
	}
}
