Hi,

This is my Project1 Unit5.
First run as Unit 4 to add models.
Then run as Unit 5 on server. 
And please use a browser to see the select and configuration process and the results.
Login: http://localhost:8080/Java_Proj1_U5_Client/SelectModel

I used Tomcat 7.0 as the server, and you may need to add servlet-api.jar (included in my submission) to run my program.

Thanks very much!
Pinchao