package model;

import java.io.Serializable;
import java.util.ArrayList;


/*
 * OptionSet - Define inner class
 * Each automobile object contains a number of option set objects (stored in linked hash map)
 */
public class OptionSet implements Serializable{
	/**
	 * Add generated serial version id
	 */
	private static final long serialVersionUID = 579552938959361877L;
	
	private ArrayList<Option> optList;
	private Option optionChoice = null;
	
	protected OptionSet(){
		super();
		this.optList = new ArrayList<Option>();
	}

	protected synchronized ArrayList<Option> getOpt() {
		return optList;
	}
	
	protected synchronized Option getOptionChoice(){
		return optionChoice;
	}
	
	protected synchronized void setOptionChoice(String OptionName){
		for (int i=0; i<optList.size(); i++){
			if (optList.get(i).getName().equals(OptionName)){
				this.optionChoice = optList.get(i);
			}
		}
	}
	
	protected synchronized Option setOptionValues(String name, float price) {
		Option opt = new Option();
		opt.setName(name);
		opt.setPrice(price);
		return opt;
	}
	
	protected synchronized String print(){
		StringBuffer stringBuffer = new StringBuffer();
		for (int optIndex=0; optIndex<optList.size(); optIndex++){
			stringBuffer.append("\n");
			stringBuffer.append(optList.get(optIndex).print());
		}
		return stringBuffer.toString();
	}


	/*
	 * Option - Define inner class
	 * Each option set object contains a number of options (stored in array list)
	 */
	class Option implements Serializable {
		/**
		 * Add generated serial version id
		 */
		private static final long serialVersionUID = 3317554985361008112L;
		private String name;
		float price;
		
		public synchronized String getName() {
			return name;
		}
		protected synchronized float getPrice() {
			return price;
		}
		
		protected synchronized void setName(String name) {
			this.name = name;
		}
		protected synchronized void setPrice(float price) {
			this.price = price;
		}
		
		protected synchronized String print(){
			StringBuffer stringBuffer = new StringBuffer(name);
			stringBuffer.append(" - Price: $");
			stringBuffer.append(price);
			return stringBuffer.toString();
		}
	}
}
