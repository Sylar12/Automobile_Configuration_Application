package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

import javax.swing.text.html.Option;

public class Automobile implements Serializable {
	private String make;
	private String model;
	private float baseprice;
	private LinkedHashMap<String, OptionSet> opsetList;	
	
	// Constructors
	public Automobile(){
		super();
		this.model = null;
		this.baseprice = 0;
		this.opsetList = new LinkedHashMap<String, OptionSet>();
	}

	public Automobile (String n, float price){
		this.model = n;
		this.baseprice = price;
		this.opsetList = new LinkedHashMap<String, OptionSet>();
	}

	// Getters
	public String getMake() {
		return make;
	}
	
	public String getModel() {
		return model;
	}
	
	public float getBaseprice() {
		return baseprice;
	}
	
	public OptionSet getOpset(String opsetName) {
		return this.opsetList.get(opsetName);
	}
	
	public String getOptionChoice(String opsetName){
		return opsetList.get(opsetName).getOptionChoice().getName();
	}
	
	public float getOptionChoicePrice(String opsetName){
		return opsetList.get(opsetName).getOptionChoice().getPrice();
	}
	
	public float getTotalPrice(){
		float totalPrice = 0;
		Iterator<String> iter = opsetList.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			totalPrice += opsetList.get(key).getOptionChoice().getPrice();
		}
		return totalPrice;
	}
	
	// Find
	public OptionSet findOpsetWithName(String opsetName){
		return opsetList.get(opsetName);
	}
	
	public OptionSet.Option findOptWithName(String optName){
		Iterator<String> iter = opsetList.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			OptionSet optList = opsetList.get(key);
			for (int j=0; j<optList.getOpt().size(); j++){
				if (optList.getOpt().get(j).getName().equals(optName)){
					return optList.getOpt().get(j);
				}
			}
		}
		return null;
	}

	// Setters
	public void setMake(String make) {
		this.make = make;
	}
	
	public void setModel(String model) {
		this.model = model;
	}

	public void setBaseprice(float baseprice) {
		this.baseprice = baseprice;
	}

	public void setOpsetValues(String opsetName) {
		OptionSet opset = new OptionSet(opsetName);
		opsetList.put(opsetName, opset);
	}
	
	public void setOptionValues(String opsetName, String name, float price){
		this.opsetList.get(opsetName).getOpt().add(opsetList.get(opsetName).setOptionValues(name, price));
	}
	
	public void setOptionChoice(String opsetName, String optionName){
		opsetList.get(opsetName).setOptionChoice(optionName);
	}
	
	// Update
	public void updateOpset(String opsetName, String newName){
		opsetList.get(opsetName).setName(newName);
	}
	
	public void updateOpt(String opsetName, String optName, float price){
		OptionSet OptList = opsetList.get(opsetName);
		for (int j=0; j<OptList.getOpt().size(); j++){
			if (OptList.getOpt().get(j).getName().equals(optName)){
				OptList.getOpt().get(j).setPrice(price);
				break;
			}
		}
	}
	
	public void deleteOpset(String opsetmodel){
		opsetList.remove(opsetmodel);
	}
	
	public void deleteOpt(String opsetName, String optName){
		OptionSet OptList = opsetList.get(opsetName);
		for (int j=0; j<OptList.getOpt().size(); j++){
			if (OptList.getOpt().get(j).getName().equals(optName)){
				OptList.getOpt().remove(j);
				break;
			}
		}
	}
	
	// Print automobile model, base price and options
	public String print(){
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append("Make: ");
		stringBuffer.append(make + "\n");
		stringBuffer.append("Model: ");
		stringBuffer.append(model +"\n");
		stringBuffer.append("Base Price: $");
		stringBuffer.append(baseprice);
		
		Iterator<String> iter = opsetList.keySet().iterator();
		while(iter.hasNext()) {
			String key = iter.next();
			OptionSet optList = opsetList.get(key);
			stringBuffer.append("\n\n");
			stringBuffer.append(optList.print());	
		}
		return stringBuffer.toString();
	}
}
