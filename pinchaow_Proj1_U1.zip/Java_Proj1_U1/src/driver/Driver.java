package driver;

import java.io.FileNotFoundException;
import java.io.IOException;

import util.*;
import model.Automotive;

public class Driver {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		String autoName = "Focus Wagon ZTW";
		float basePrice = 18445;
		int optionSetSize = 5;
		
		Automotive FordZTW = new Automotive(autoName, basePrice, optionSetSize);
		FileIO fileIO = new FileIO();
		FordZTW = fileIO.buildAutoObject("AutomotiveInput.txt", FordZTW);
		//Print attributes before serialization
		System.out.println("//Print attributes before serialization");
		System.out.println(FordZTW.print() + "\n\n");
		
		FileIO fileIOser = new FileIO();
		fileIOser.serializeAuto(FordZTW, "auto.ser");
		Automotive newFordZTW = fileIOser.deserializeAuto("auto.ser");
		//Print new attributes
		System.out.println("//Print new attributes");
		System.out.println(newFordZTW.print() + "\n\n");
	}
}
