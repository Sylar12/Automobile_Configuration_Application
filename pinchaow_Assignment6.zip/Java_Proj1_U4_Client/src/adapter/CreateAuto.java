package adapter;

public interface CreateAuto {
	String buildAuto(String fileName, String fileType);
	void printAuto(String modelName);
}
