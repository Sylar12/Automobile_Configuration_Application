package adapter;

public interface CreateAuto {
	String buildAuto(String fileName);
	void printAuto(String modelName);
}
