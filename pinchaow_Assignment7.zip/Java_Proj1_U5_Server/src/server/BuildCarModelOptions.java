package server;
import adapter.ProxyAutoMobile;
import model.Automobile;

public class BuildCarModelOptions extends ProxyAutoMobile implements AutoServer{
	/**
	 * Add generated serial version ID.
	 */
	private static final long serialVersionUID = 4080403325092669557L;

	public void buildCarModelOptions(String modelName, Automobile auto) {
		buildCarModelOptions(modelName, auto);
	}

	public String printAllModelNames() {
		return printAllModelNames();
	}

	public Automobile returnSelectedAuto(String modelName) {
		return returnSelectedAuto(modelName);
	}
}
