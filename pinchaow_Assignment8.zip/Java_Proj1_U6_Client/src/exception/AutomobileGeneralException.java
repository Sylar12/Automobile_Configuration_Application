package exception;

public class AutomobileGeneralException extends Exception{
	
	/**
	 * Add generated serial version id
	 */
	private static final long serialVersionUID = 2014554445383635753L;

	public AutomobileGeneralException(String msg){
		super(msg);
	}
}
