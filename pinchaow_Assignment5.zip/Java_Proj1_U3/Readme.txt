Hi,

This is my Project1 Unit3.
I want to test both threads synchronized or threads without synchronization, manually and automatically. Since threads without synchronization may cause data corruption, I did not test all these kinds of threads at the same run, because the corruption may affect threads synchronized. Thus I did the tests separately.

Here I did 4 tests by changing the arguments in EditOptions in Driver.java.

Test 1: (Threads: case 1, case 1)
Change OptionSet Name manually (synchronized), worked out fine.

Test 2: (Threads: case 7, case 8)
Change Option Price automatically (synchronized), worked out fine.

Test 3: (Threads: case 5, case6)
Change OptionSet Name automatically (without synchronization), caused data corruption.

Test 4: (Threads: case 4, case 4)
Change Option Price manually (without synchronization), caused data corruption.