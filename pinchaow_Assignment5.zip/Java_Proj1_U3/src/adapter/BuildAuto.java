package adapter;

public class BuildAuto extends ProxyAutoMobile implements CreateAuto, UpdateAuto, EditThread {

	/**
	 * Add generated serial version ID.
	 */
	static final long serialVersionUID = -8139368354614205281L;
	
}
