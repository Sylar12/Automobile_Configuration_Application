package exception;

public class AutoOptionException extends Exception {
	private String msg;
	
	public AutoOptionException(String message){
		this.msg = message;
	}
	
	public String getMsg(){
		return msg;
	}	
}
