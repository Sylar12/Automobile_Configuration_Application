package driver;

import scale.EditOptions;
import adapter.BuildAuto;
import scale.EditThread;

public class Driver_U3 {
	public void startTest(){
		System.out.println("**TEST FOR MULTITHREADING**");
		System.out.println("========================");
		BuildAuto testAutoShop = new BuildAuto();
		String modelName = testAutoShop.buildAuto("Focus_Wagon_ZTW.txt", "textFile");
		testAutoShop.printAuto(modelName);
		
		EditThread et = new BuildAuto();
		EditOptions eo1 = new EditOptions(modelName, et, 1);
		EditOptions eo2 = new EditOptions(modelName, et, 1);
		
		eo1.start();
		eo2.start();
		
		/*
		    *  Here we always create 2 threads to edit the same object.
			*  
			*  Test with synchronization statement:
			*  Assume thread 0 enters first, it will lock the auto object, and changes the thread name from "Color" to "Color1".
			*  When thread 1 enters and tries to edit the option set name, the option set names displayed should have become "Color1"
			*  And thread 1 could change option set name from "Color1" to "Color2"
			*  (Same for editing option price)
			*  
			*  Test without synchronization statement:
			*  Both threads can reach the object during the process. The "faster" thread changes the "Color" to its goal value.
			*  The "slower" thread fails to can not change the value from "Color" to its goal value.
			*  This is because the option set name has already been edited to the faster thread's goal value.
			*  And the slower thread could not find a "Color" option anymore. (Has been changed)
			*  
			*  From above, we could find that removing synchronization will cause data corruption.
			*/
	}
}
