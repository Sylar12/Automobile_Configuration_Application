package adapter;
import java.io.Serializable;
import java.util.LinkedHashMap;

import util.FileIO;
import model.*;

public abstract class ProxyAutomobile implements Serializable {
	private LinkedHashMap<String, Automobile> autoShop = new LinkedHashMap<String, Automobile>();
	
	public void buildAuto(String modelName, String fileName){
		FileIO fileIO = new FileIO();
		autoShop.put(modelName, fileIO.buildAutoObject(fileName));
	}
	
	public void printAuto(String modelName){
		System.out.println(autoShop.get(modelName).print());
	}
	
	public void updateOptionSetName(String modelName, String opsetName, String newName){
		autoShop.get(modelName).updateOpset(opsetName, newName);
	}
	
	public void updateOptionPrice(String modelName, String opsetName, String optName, float newPrice){
		autoShop.get(modelName).updateOpt(opsetName, optName, newPrice);
	}
	
	public void setOptionChoice(String modelName, String opsetName, String optName){
		autoShop.get(modelName).setOptionChoice(opsetName, optName);
	}
	
	public String getOptionChoice(String modelName, String opsetName){
		return autoShop.get(modelName).getOptionChoice(opsetName);
	}
	
	public float getOptionChoicePrice(String modelName, String opsetName){
		return autoShop.get(modelName).getOptionChoicePrice(opsetName);
	}
}
