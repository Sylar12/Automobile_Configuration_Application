Hi,
My code will test the functions mentioned on the write up.

Test Case 1: To create and print an Auto instance through CreateAuto interface.
Test Case 2: To update one of OptionSet’s name or Option Price for the Auto instance created in previous step.
Test Case 3: Exception - Missing filename or wrong filename
Test Case 4: Exception - Missing OptionSet data (Make)
Test Case 5: Exception - Missing OptionSet data (Model)
Test Case 6: Exception - Missing price for Automobile in Text file
Test Case 7: Exception - Missing option data

For the missing part, you need to input manually.
And I have write my name in code “Driver.java”.

Thanks,
Pinchao