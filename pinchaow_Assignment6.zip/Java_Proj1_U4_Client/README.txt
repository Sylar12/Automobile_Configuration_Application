Hi,
This is my Project 1 Unit 4.
Please run the server and client program. And follow the instruction in the console to add property file, select model, configure model and select options.

Start:
Add property file
Configure Car
Show Models
Select a model
Select options
End

Thanks.