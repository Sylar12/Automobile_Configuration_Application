package adapter;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Scanner;

import database.*;
import util.FileIO;
import model.*;

public abstract class DBProxyAutomobile implements Serializable {
	/**
	 * Add generated serial version id
	 */
	private static final long serialVersionUID = -4263531946085598548L;
	private static LinkedHashMap<String, Automobile> autoShop = new LinkedHashMap<String, Automobile>();
	
	private String serverName = "localhost";
	private String portNumber = "3306";
	private String dbName = "DBAutomobiles";

	private String username = "root";
	private String password = "";
	
	
//	public static LinkedHashMap<String, Automobile> getAuto_shop() {
//		return auto_shop;
//	}

	public String  buildAuto(String fileName){
		FileIO fileIO = new FileIO();
		Automobile automobile = fileIO.buildAutoObject(fileName);

		autoShop.put(automobile.getModel(), automobile);
		createAutoDB(autoShop.get(automobile.getModel()));
		return automobile.getModel();
	}
	
	public void deleteAuto(String modelName){
		autoShop.remove(modelName);
		deleteAutoDB(modelName);
	}
	
	public void printAuto(String modelName){
		System.out.println(autoShop.get(modelName).toString());
	}
	
	/*
	 * Function for editing option set names: (Automatically)
	 * To set new option set name for certain option set.
	 * If the option set name to be edited does not exist, an exception will be thrown.
	 */
	public void updateOptionSetName(String modelName, String opsetName, String newName){
		synchronized(autoShop.get(modelName)){
			autoShop.get(modelName).updateOpsetName(opsetName, newName);
			Iterator<String> iter_1 = autoShop.get(modelName).getOpsetList().keySet().iterator();
			System.out.println("\n** Current option set names are:");
			while(iter_1.hasNext()){
				System.out.println(iter_1.next());
			}
		}
	}
	
	public void updateOptionSetNameNo(String modelName, String opsetName, String newName){
		autoShop.get(modelName).updateOpsetName(opsetName, newName);
		Iterator<String> iter_1 = autoShop.get(modelName).getOpsetList().keySet().iterator();
		System.out.println("\n** Current option set names are:");
		while(iter_1.hasNext()){
			System.out.println(iter_1.next());
		}
	}
	
	/*
	 * Function for editing options price: (Automatically)
	 * To set new price for certain option in certain option set
	 */
	public void updateOptionPriceNo(String modelName, String opsetName, String optName, float newPrice){
		autoShop.get(modelName).updateOpt(opsetName, optName, newPrice);
		System.out.println("\nCurrent automobile information is:");
		System.out.println(autoShop.get(modelName).toString());
	}
	
	public void updateOptionPrice(String modelName, String opsetName, String optName, float newPrice){
		synchronized(autoShop.get(modelName)){
			autoShop.get(modelName).updateOpt(opsetName, optName, newPrice);
	//	System.out.println("\nCurrent automobile information is:");
	//	System.out.println(autoShop.get(modelName).toString());
			updateOptPriceDB(modelName, opsetName, optName, newPrice);
		}
	}
	
	public void setOptionChoice(String modelName, String opsetName, String optName){
		autoShop.get(modelName).setOptionChoice(opsetName, optName);
	}
	
	public String getOptionChoice(String modelName, String opsetName){
		return autoShop.get(modelName).getOptionChoice(opsetName);
	}
	
	public float getOptionChoicePrice(String modelName, String opsetName){
		return autoShop.get(modelName).getOptionChoicePrice(opsetName);
	}
	
	/*
	 * Function for editing option set names: (Manually) 
	 * Step 1: To ask users to select option set that is going to be edited.
	 * Step 2: To asks users to input new name for that option set.
	 * Step 3: To prints new option set names after the edit operation
	 * If the option set name to be edited does not exist, an exception will be thrown.
	 */
	public void editOpsetName(String modelName){
		synchronized(autoShop.get(modelName)){
			Thread currThread = Thread.currentThread();
			System.out.println("\n===============================");
			System.out.println("Test of multithreading - edit opset/option");
			System.out.println("Current running thread is:" + currThread.getName());
			
			Iterator<String> iter = autoShop.get(modelName).getOpsetList().keySet().iterator();
			System.out.println("");
			while(iter.hasNext()){
				System.out.println(iter.next());
			}

			System.out.println("\nPlease enter the option set name you want to edit:");
			Scanner sc_old = new Scanner(System.in);
			String oldOpsetName = sc_old.nextLine();
			
			System.out.println("\nPlease enter the new option set name:");
			Scanner sc_new = new Scanner(System.in);
			String newOpsetName = sc_new.nextLine();
			autoShop.get(modelName).updateOpsetName(oldOpsetName, newOpsetName);
			
			Iterator<String> iter_1 = autoShop.get(modelName).getOpsetList().keySet().iterator();
			System.out.println("\n** Current option set names are:");
			while(iter_1.hasNext()){
				System.out.println(iter_1.next());
			}
		}
	}
	
	public void editOpsetNameNo(String modelName){
		Thread currThread = Thread.currentThread();
		System.out.println("\n===============================");
		System.out.println("Test of multithreading - edit OptionSet name");
		System.out.println("Current running thread is:" + currThread.getName());
		
		Iterator<String> iter = autoShop.get(modelName).getOpsetList().keySet().iterator();
		System.out.println("");
		while(iter.hasNext()){
			System.out.println(iter.next());
		}

		System.out.println("\nPlease enter the option set name you want to edit:");
		Scanner sc_old = new Scanner(System.in);
		String oldOpsetName = sc_old.nextLine();
		
		System.out.println("\nPlease enter the new option set name:");
		Scanner sc_new = new Scanner(System.in);
		String newOpsetName = sc_new.nextLine();
		autoShop.get(modelName).updateOpsetName(oldOpsetName, newOpsetName);
		
		Iterator<String> iter_1 = autoShop.get(modelName).getOpsetList().keySet().iterator();
		System.out.println("\n** Current option set names are:");
		while(iter_1.hasNext()){
			System.out.println(iter_1.next());
		}
		}
	
	/*
	 * Function for editing options price: (Manually)
	 * Step 1: To asks users to select a option set that is going to be edited .
	 * Step 2: To asks users to select a option  that is going to be edited. 
	 * Step 3: To asks users to input new price for that option.
	 * Step 4: To print new automobile information after the edit operation
	 * If the option set name or option name to be edited does not exist, an exception will be thrown.
	 */
	public void editOption(String modelName){
		synchronized(autoShop.get(modelName)){
			Thread currThread = Thread.currentThread();
			System.out.println("\n===============================");
			System.out.println("Test of multithreading - edit opset/option");
			System.out.println("Current running thread is:" + currThread.getName());
			
			System.out.println("\nPlease enter the option set name you want to edit:");
			Scanner sc_opset = new Scanner(System.in);
			String opsetName = sc_opset.nextLine();

			System.out.println("\nPlease enter the option name you want to edit:");
			Scanner sc_optionName = new Scanner(System.in);
			String newOpsetName = sc_optionName.nextLine();
			
			System.out.println("\nPlease enter new option price:");
			Scanner sc_optionPrice = new Scanner(System.in);
			float newOpsetPrice = Float.parseFloat(sc_optionPrice.nextLine());
			autoShop.get(modelName).updateOpt(opsetName, newOpsetName, newOpsetPrice);
			
			System.out.println("\nCurrent automobile information is:");
			System.out.println(autoShop.get(modelName).toString());
		}
	}
	
	public void editOptionNo(String modelName){
		Thread currThread = Thread.currentThread();
		System.out.println("\n===============================");
		System.out.println("Test of multithreading - edit opset/option");
		System.out.println("Current running thread is:" + currThread.getName());
		
		System.out.println("\nPlease enter the option set name you want to edit:");
		Scanner sc_opset = new Scanner(System.in);
		String opsetName = sc_opset.nextLine();

		System.out.println("\nPlease enter the option name you want to edit:");
		Scanner sc_optionName = new Scanner(System.in);
		String newOpsetName = sc_optionName.nextLine();
		
		System.out.println("\nPlease enter new option price:");
		Scanner sc_optionPrice = new Scanner(System.in);
		float newOpsetPrice = Float.parseFloat(sc_optionPrice.nextLine());
		autoShop.get(modelName).updateOpt(opsetName, newOpsetName, newOpsetPrice);
		
		System.out.println("\nCurrent automobile information is:");
		System.out.println(autoShop.get(modelName).toString());
	}
	
	public void buildCarModelOptions(String modelName, Automobile auto){
		autoShop.put(modelName, auto);
	}
	
	public String printAllModelNames(){
		Iterator<String> iter = autoShop.keySet().iterator();
		StringBuffer sB = new StringBuffer();
		while(iter.hasNext()){
			sB.append(iter.next());
			sB.append(";");	
		}
		return sB.toString();
	}
	
	public Automobile returnSelectedAuto(String modelName){
		Automobile auto = autoShop.get(modelName);
		return auto;
	}
	
	//Some Operations of DB
	public void createAutoDB(Automobile auto){
		DBCreateAuto cA = new DBCreateAuto(serverName, portNumber, dbName, username, password);
		cA.createAuto(auto);
	}
	
	public void deleteAutoDB(String modelName){
		DBDeleteAuto dA = new DBDeleteAuto(serverName, portNumber, dbName, username, password);
		dA.deleteAuto(modelName);
	}
	
	public void updateOptPriceDB(String modelName, String opsetName, String optName, float newPrice){
		DBUpdateOptionPrice uOP = new DBUpdateOptionPrice(serverName, portNumber, dbName, username, password);
		uOP.updateOptionPrice(modelName, opsetName, optName, newPrice);
	}
}
