package driver;
//Andrew ID: pinchaow
//Name: Pinchao Wang
import java.io.FileNotFoundException;
import java.io.IOException;
import scale.EditOptions;
import adapter.BuildAuto;
import adapter.EditThread;

public class Driver {
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		System.out.println("##Test of multithreading##");
		System.out.println("========================");
		BuildAuto testAutoShop = new BuildAuto();
		testAutoShop.buildAuto("Focus Wagon ZTW", "Focus_Wagon_ZTW.txt");
		testAutoShop.printAuto("Focus Wagon ZTW");
		
		EditThread et = new BuildAuto();
		//Change the arguments to test different situations.
		EditOptions eo1 = new EditOptions("Focus Wagon ZTW", et, 1);
		EditOptions eo2 = new EditOptions("Focus Wagon ZTW", et, 1);
		
		eo1.start();
		eo2.start();
		
		 /*
		    *  Here we always create 2 threads to edit the same object.
			*  
			*  Test with synchronization statement:
			*  Assume thread 0 enters first, it will lock the auto object, and changes the thread name from "Color" to "Color1".
			*  When thread 1 enters and tries to edit the option set name, the option set names displayed should have become "Color1"
			*  And thread 1 could change option set name from "Color1" to "Color2"
			*  (Same for editing option price)
			*  
			*  Test without synchronization statement:
			*  Both threads can reach the object during the process. The "faster" thread changes the "Color" to its goal value.
			*  The "slower" thread fails to can not change the value from "Color" to its goal value.
			*  This is because the option set name has already been edited to the faster thread's goal value.
			*  And the slower thread could not find a "Color" option anymore. (Has been changed)
			*  
			*  From above, we could find that removing synchronization will cause data corruption.
			*/
	}
}