package scale;

import adapter.EditThread;

public class EditOptions extends Thread {
	private String modelName;
	private int op; 
	private EditThread et;
	
	public EditOptions(String model_name, EditThread edit_threat, int operation){
		modelName = model_name;
		et = edit_threat;
		op = operation;
	}
	
	public void run(){
		//synchronized(System.out){
			switch (op){
			// Manually Edit Methods
			case 1: 
				et.editOpsetName(modelName); // change optionSet Name with synchronized
				break;
			case 2:
				et.editOpsetNameNo(modelName); // change optionSet Name without synchronized
				break;	
			case 3:
				et.editOption(modelName); //change option price with synchronized
				break;
			case 4:
				et.editOptionNo(modelName); //change option price without synchronized
				break;
				
			// Automatically Edit Methods
			case 5:
				et.updateOptionSetNameNo(modelName, "Color", "Color1");	//change optionSet Name without synchronized
				break;
			case 6:
				et.updateOptionSetNameNo(modelName, "Color", "Color2");	//change optionSet Name without synchronized
				break;
			case 7:
				et.updateOptionPrice(modelName, "Color", "Cloud 9 White Clearcoat", 12);	//change option price without synchronized
				break;
			case 8:
				et.updateOptionPrice(modelName, "Color", "Cloud 9 White Clearcoat", 13);	//change option price without synchronized
				break;
			}
		//}
	}
}
