package model;

import java.io.Serializable;
import java.util.ArrayList;


public class OptionSet implements Serializable{
	private String name;
	private ArrayList<Option> optList;
	private Option optionChoice = null;
	
	public OptionSet(){
		super();
		this.name = null;
		this.optList = new ArrayList<Option>();
	}
	
	protected OptionSet(String n){
		super();
		this.name = n;
		this.optList = new ArrayList<Option>();
	}

	protected String getName() {
		return name;
	}

	protected void setName(String name) {
		this.name = name;
	}

	protected ArrayList<Option> getOpt() {
		return optList;
	}

	protected void setOpt(ArrayList<Option> opt) { 
		this.optList = opt;
	}
	
	protected Option getOptionChoice(){
		return optionChoice;
	}
	
	protected void setOptionChoice(String OptionName){
		for (int i=0; i<optList.size(); i++){
			if (optList.get(i).getName().equals(OptionName)){
				this.optionChoice = optList.get(i);
			}
		}
	}
	
	public Option setOptionValues(String name, float price) {
		Option opt = new Option();
		opt.setName(name);
		opt.setPrice(price);
		return opt;
	}
	
	protected String print(){
		StringBuffer stringBuffer = new StringBuffer(name + ":");
		for (int optIndex=0; optIndex<optList.size(); optIndex++){
			stringBuffer.append("\n");
			stringBuffer.append(optList.get(optIndex).print());
		}
		return stringBuffer.toString();
	}


// inner class Option
public class Option implements Serializable {
	private String name;
	float price;
	
	public String getName() {
		return name;
	}
	protected void setName(String name) {
		this.name = name;
	}
	protected float getPrice() {
		return price;
	}
	protected void setPrice(float price) {
		this.price = price;
	}
	
	protected String print(){
		StringBuffer stringBuffer = new StringBuffer(name);
		stringBuffer.append(" - Price: $");
		stringBuffer.append(price);
		return stringBuffer.toString();
	}
}
}
