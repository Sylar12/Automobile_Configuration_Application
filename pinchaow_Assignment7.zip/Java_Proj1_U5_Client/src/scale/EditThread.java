package scale;

public interface EditThread {
	// Manually input to edit
	void editOpsetName(String modelName);
	void editOpsetNameNo(String modelName);
	void editOption(String modelName);
	void editOptionNo(String modelName);
	
	// Automatically edit
	void updateOptionSetName(String modelName, String opsetName, String newName);
	void updateOptionSetNameNo(String modelName, String opsetName, String newName);
	void updateOptionPrice(String modelName, String opsetName, String optName, float newPrice);
	void updateOptionPriceNo(String modelName, String opsetName, String optName, float newPrice);
}
