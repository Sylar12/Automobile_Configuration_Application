package util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Properties;

import model.Automobile;
import exception.AutomobileExceptions.MissBasePrice;
import exception.AutomobileExceptions.MissFileName;
import exception.AutomobileExceptions.MissMake;
import exception.AutomobileExceptions.MissModel;
import exception.AutomobileExceptions.MissOptionPrice;
import adapter.BuildAuto;

public class FileIO {
private Automobile automobile = new Automobile();
	
	public Automobile buildAutoObject(String fileName){
		try{
			// Check the input file name
			if (fileName.length() == 0){
				throw new MissFileName("File name is missing!");
			}
			
			// Create FileReader to read file
			FileReader file = new FileReader(fileName);
			BufferedReader buff = new BufferedReader(file);
			boolean eof = false;
			
			// Check whether field "Make" exists or not, if not, throw exception and add the right value
			String autoMake = null;
			String makelLine = buff.readLine();
			makelLine.split(":");
			try{
				if (makelLine.split(":")[0].equals("Make") && makelLine.split(":").length != 2)
					throw new MissMake("'Make' field is missing!");
				else
					autoMake = makelLine.split(":")[1];
			} catch (MissMake e){
				System.out.println(e.getMessage());
				autoMake = e.getMake();
			} 
			automobile.setMake(autoMake);
			
			// Check whether field "Model" exists or not, if not, throw exception and add the right value
			String autoName = null;
			String modelLine = buff.readLine();
			modelLine.split(":");
			try{
				if (modelLine.split(":")[0].equals("Model") && modelLine.split(":").length != 2)
					throw new MissModel("'Model' field is missing! ");
				else
					autoName = modelLine.split(":")[1];
			} catch (MissModel e){
				System.out.println(e.getMessage());
				autoName = e.getModel();
			} 
			automobile.setModel(autoName);
			
			// Check whether field "Base Price" exists or not, if not, throw exception and add the right value
			float autoBasePrice = (float) 0.0;
			String basePriceLine = buff.readLine();
			basePriceLine.split(":");
			try{
				if (basePriceLine.split(":")[0].equals("Base Price") && basePriceLine.split(":").length != 2)
					throw new MissBasePrice("'Base Price' field is missing!");
				else
					autoBasePrice = Float.parseFloat(basePriceLine.split(":")[1]);
			} catch (MissBasePrice e){
				System.out.println(e.getMessage());
				autoBasePrice = Float.parseFloat(e.getModel());
			}
			automobile.setBaseprice(autoBasePrice);
			
			/*
			 * Start to read input file line by line, get Option Set and Options
			 * Each line in input data file contains all information for one option set.
			 * The structure is as below:
			 * 		Option set name and options are separated by ":"
			 * 		Options are separated by ";"
			 * 		Option name and price are separated by ","
			 */
			while (eof != true){
				String line = buff.readLine();
				
				if (line == null){
					eof = true;
				} else {
					String[] opset = line.split(":");
					String opsetName = opset[0];
					String opsetString = opset[1];

					String[] opt = opsetString.split(";");
					int optionSize = opt.length;
					
					
					automobile.setOpsetValues(opsetName); 
					for (int optIndex=0; optIndex<optionSize; optIndex++){
						String[] optSplit = opt[optIndex].split(",");
						
						// Check Option data (Option Price), if not exists, input the right value
						String optName = optSplit[0];
						String optString = null;
						
						float optPrice = 0;
						try{
							if (optSplit.length != 2)
								throw new MissOptionPrice("Missing option data! " +
										"Please check option set '" + opsetName +
										"', option '" + optName);
							else {
								optString = optSplit[1];
								optPrice = Float.parseFloat(optString);
							}
						} catch (MissOptionPrice e){
							System.out.println(e.getMessage());
							optPrice = Float.parseFloat(e.getOptionPrice());
						}
						automobile.setOptionValues(opsetName, optName, optPrice);
					}
				}
			}
			buff.close();
		} catch (MissFileName e){
			System.out.println(e.getMessage());
		} catch (IOException e){
			System.out.println("Error -- " + e.toString());
		}
		return automobile;
	}
	
	public Automobile buildAutoFromPropertyObject(Properties props){
		String CarModel = props.getProperty("CarModel");
		if(!CarModel.equals(null)){
			String CarMake = props.getProperty("CarMake");
			float BasePrice = Float.parseFloat(props.getProperty("BasePrice"));
			
			String OptionSet1 = props.getProperty("OptionSet1");
			String OptionSet1_Option1_Name = props.getProperty("OptionSet1_Option1_Name");
			float OptionSet1_Option1_Price = Float.parseFloat(props.getProperty("OptionSet1_Option1_Price"));
			String OptionSet1_Option2_Name = props.getProperty("OptionSet1_Option2_Name");
			float OptionSet1_Option2_Price = Float.parseFloat(props.getProperty("OptionSet1_Option2_Price"));
			String OptionSet1_Option3_Name = props.getProperty("OptionSet1_Option3_Name");
			float OptionSet1_Option3_Price = Float.parseFloat(props.getProperty("OptionSet1_Option3_Price"));
			String OptionSet1_Option4_Name = props.getProperty("OptionSet1_Option4_Name");
			float OptionSet1_Option4_Price = Float.parseFloat(props.getProperty("OptionSet1_Option4_Price"));
			String OptionSet1_Option5_Name = props.getProperty("OptionSet1_Option5_Name");
			float OptionSet1_Option5_Price = Float.parseFloat(props.getProperty("OptionSet1_Option5_Price"));
			String OptionSet1_Option6_Name = props.getProperty("OptionSet1_Option6_Name");
			float OptionSet1_Option6_Price = Float.parseFloat(props.getProperty("OptionSet1_Option6_Price"));
			String OptionSet1_Option7_Name = props.getProperty("OptionSet1_Option7_Name");
			float OptionSet1_Option7_Price = Float.parseFloat(props.getProperty("OptionSet1_Option7_Price"));
			String OptionSet1_Option8_Name = props.getProperty("OptionSet1_Option8_Name");
			float OptionSet1_Option8_Price = Float.parseFloat(props.getProperty("OptionSet1_Option8_Price"));
			String OptionSet1_Option9_Name = props.getProperty("OptionSet1_Option9_Name");
			float OptionSet1_Option9_Price = Float.parseFloat(props.getProperty("OptionSet1_Option9_Price"));
			String OptionSet1_Option10_Name = props.getProperty("OptionSet1_Option10_Name");
			float OptionSet1_Option10_Price = Float.parseFloat(props.getProperty("OptionSet1_Option10_Price"));
			
			String OptionSet2 = props.getProperty("OptionSet2");
			String OptionSet2_Option1_Name = props.getProperty("OptionSet2_Option1_Name");
			float OptionSet2_Option1_Price = Float.parseFloat(props.getProperty("OptionSet2_Option1_Price"));
			String OptionSet2_Option2_Name = props.getProperty("OptionSet2_Option2_Name");
			float OptionSet2_Option2_Price = Float.parseFloat(props.getProperty("OptionSet2_Option2_Price"));
			
			String OptionSet3 = props.getProperty("OptionSet3");
			String OptionSet3_Option1_Name = props.getProperty("OptionSet3_Option1_Name");
			float OptionSet3_Option1_Price = Float.parseFloat(props.getProperty("OptionSet3_Option1_Price"));
			String OptionSet3_Option2_Name = props.getProperty("OptionSet3_Option2_Name");
			float OptionSet3_Option2_Price = Float.parseFloat(props.getProperty("OptionSet3_Option2_Price"));
			String OptionSet3_Option3_Name = props.getProperty("OptionSet3_Option3_Name");
			float OptionSet3_Option3_Price = Float.parseFloat(props.getProperty("OptionSet3_Option3_Price"));
			
			String OptionSet4 = props.getProperty("OptionSet4");
			String OptionSet4_Option1_Name = props.getProperty("OptionSet4_Option1_Name");
			float OptionSet4_Option1_Price = Float.parseFloat(props.getProperty("OptionSet4_Option1_Price"));
			String OptionSet4_Option2_Name = props.getProperty("OptionSet4_Option2_Name");
			float OptionSet4_Option2_Price = Float.parseFloat(props.getProperty("OptionSet4_Option2_Price"));
			
			String OptionSet5 = props.getProperty("OptionSet5");
			String OptionSet5_Option1_Name = props.getProperty("OptionSet5_Option1_Name");
			float OptionSet5_Option1_Price = Float.parseFloat(props.getProperty("OptionSet5_Option1_Price"));
			String OptionSet5_Option2_Name = props.getProperty("OptionSet5_Option2_Name");
			float OptionSet5_Option2_Price = Float.parseFloat(props.getProperty("OptionSet5_Option2_Price"));
		
			automobile.setModel(CarModel);
			automobile.setMake(CarMake);
			automobile.setBaseprice(BasePrice);
			
			automobile.setOpsetValues(OptionSet1);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option1_Name, OptionSet1_Option1_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option2_Name, OptionSet1_Option2_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option3_Name, OptionSet1_Option3_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option4_Name, OptionSet1_Option4_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option5_Name, OptionSet1_Option5_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option6_Name, OptionSet1_Option6_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option7_Name, OptionSet1_Option7_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option8_Name, OptionSet1_Option8_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option9_Name, OptionSet1_Option9_Price);
			automobile.setOptionValues(OptionSet1, OptionSet1_Option10_Name, OptionSet1_Option10_Price);
			
			automobile.setOpsetValues(OptionSet2);
			automobile.setOptionValues(OptionSet2, OptionSet2_Option1_Name, OptionSet2_Option1_Price);
			automobile.setOptionValues(OptionSet2, OptionSet2_Option2_Name, OptionSet2_Option2_Price);
			
			automobile.setOpsetValues(OptionSet3);
			automobile.setOptionValues(OptionSet3, OptionSet3_Option1_Name, OptionSet3_Option1_Price);
			automobile.setOptionValues(OptionSet3, OptionSet3_Option2_Name, OptionSet3_Option2_Price);
			automobile.setOptionValues(OptionSet3, OptionSet3_Option3_Name, OptionSet3_Option3_Price);
			
			automobile.setOpsetValues(OptionSet4);
			automobile.setOptionValues(OptionSet4, OptionSet4_Option1_Name, OptionSet4_Option1_Price);
			automobile.setOptionValues(OptionSet4, OptionSet4_Option2_Name, OptionSet4_Option2_Price);
			
			automobile.setOpsetValues(OptionSet5);
			automobile.setOptionValues(OptionSet5, OptionSet5_Option1_Name, OptionSet5_Option1_Price);
			automobile.setOptionValues(OptionSet5, OptionSet5_Option2_Name, OptionSet5_Option2_Price);
		}
		
		return automobile;
	}
	
	public void serializeAuto(BuildAuto buildAuto, String fileName) throws FileNotFoundException, IOException{
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName));
		out.writeObject(buildAuto);
		out.close();
	}
	
	public BuildAuto deserializeAuto(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException{
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
		BuildAuto buildAuto = (BuildAuto) in.readObject();
		return buildAuto;
	}
}
