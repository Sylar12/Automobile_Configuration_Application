package util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import model.Automobile;
import exception.AutoOptionException;
import adapter.BuildAuto;

public class FileIO {
private Automobile automobile = new Automobile();
	
	public Automobile buildAutoObject(String fileName){
		try{
			// Check the input file name
			if (fileName.length() == 0){
				throw new AutoOptionException("File name is missing!");
			}
			
			// Create FileReader to read file
			FileReader file = new FileReader(fileName);
			BufferedReader buff = new BufferedReader(file);
			boolean eof = false;
			
			// Check whether field "Make" exists or not, if not, throw exception and add the right value
			String autoMake = null;
			String makelLine = buff.readLine();
			makelLine.split(":");
			try{
				if (makelLine.split(":")[0].equals("Make") && makelLine.split(":").length != 2)
					throw new AutoOptionException("'Make' field is missing!");
				else
					autoMake = makelLine.split(":")[1];
			} catch (AutoOptionException e){
				System.out.println(e.getMsg());
				Scanner userInputScanner = new Scanner(System.in);
				System.out.print("\nPlease enter the 'Make' value: ");
		        autoMake = userInputScanner.nextLine();
			} 
			automobile.setMake(autoMake);
			
			// Check whether field "Model" exists or not, if not, throw exception and add the right value
			String autoName = null;
			String modelLine = buff.readLine();
			modelLine.split(":");
			try{
				if (modelLine.split(":")[0].equals("Model") && modelLine.split(":").length != 2)
					throw new AutoOptionException("'Model' field is missing! ");
				else
					autoName = modelLine.split(":")[1];
			} catch (AutoOptionException e){
				System.out.println(e.getMsg());
				Scanner userInputScanner = new Scanner(System.in);
				System.out.print("\nPlease enter the 'Model' value: ");
				autoName = userInputScanner.nextLine();
			} 
			automobile.setModel(autoName);
			
			// Check whether field "Base Price" exists or not, if not, throw exception and add the right value
			float autoBasePrice = 0;
			String basePriceLine = buff.readLine();
			basePriceLine.split(":");
			try{
				if (basePriceLine.split(":")[0].equals("Base Price") && basePriceLine.split(":").length != 2)
					throw new AutoOptionException("'Base Price' field is missing!");
				else
					autoBasePrice = Float.parseFloat(basePriceLine.split(":")[1]);
			} catch (AutoOptionException e){
				System.out.println(e.getMsg());
				Scanner userInputScanner = new Scanner(System.in);
				System.out.print("\nPlease enter the 'Base Price' value: ");
				autoBasePrice = Float.parseFloat(userInputScanner.nextLine());
			}
			automobile.setBaseprice(autoBasePrice);
			
			/*
			 * Start to read input file line by line, get Option Set and Options
			 * Each line in input data file contains all information for one option set.
			 * The structure is as below:
			 * 		Option set name and options are separated by ":"
			 * 		Options are separated by ";"
			 * 		Option name and price are separated by ","
			 */
			while (!eof){
				String line = buff.readLine();
				
				if (line == null){
					eof = true;
				} else {
					String[] opset = line.split(":");
					String opsetName = opset[0];
					String opsetString = opset[1];

					String[] opt = opsetString.split(";");
					int optionSize = opt.length;
					
					
					automobile.setOpsetValues(opsetName); 
					for (int optIndex=0; optIndex<optionSize; optIndex++){
						String[] optSplit = opt[optIndex].split(",");
						
						// Check Option data (Option Price), if not exists, input the right value
						String optName = optSplit[0];
						String optString = null;
						try{
							if (optSplit.length != 2)
								throw new AutoOptionException("Missing option data! " +
										"Please check option set '" + opsetName +
										"', option '" + optName);
							else
								optString = optSplit[1];
						} catch (AutoOptionException e){
									System.out.println(e.getMsg());
									Scanner userInputScanner = new Scanner(System.in);
									System.out.print("\nPlease enter the 'Option Price' value: ");
									optString = userInputScanner.nextLine();
						}
						float optPrice = Float.parseFloat(optString);
						automobile.setOptionValues(opsetName, optName, optPrice);
					}
				}
			}
			buff.close();
		} catch (AutoOptionException e){
			System.out.println(e.getMsg());
		} catch (IOException e){
			System.out.println("Error -- " + e.toString());
		}
		return automobile;
	}
	
	public void serializeAuto(BuildAuto buildAuto, String fileName) throws FileNotFoundException, IOException{
		ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName));
		out.writeObject(buildAuto);
		out.close();
	}
	
	public BuildAuto deserializeAuto(String fileName) throws FileNotFoundException, IOException, ClassNotFoundException{
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
		BuildAuto buildAuto = (BuildAuto) in.readObject();
		return buildAuto;
	}
}
