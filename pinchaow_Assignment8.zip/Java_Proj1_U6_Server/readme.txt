Hi,

This is my Project 1 Unit 6.
Please import the mysql-connector-java-5.0.8-bin.jar first to run the program.
I used MySQL as the database, and set the user to be root, password to be none.
Run the sever Driver_U6, the program will implements add data, delete data and update data in ListedHashMap and concurrently in database. 

Thanks very much,

Pinchao