package exception;

public class AutomobileGeneralException extends Exception{
	public AutomobileGeneralException(String msg){
		super(msg);
	}

}
