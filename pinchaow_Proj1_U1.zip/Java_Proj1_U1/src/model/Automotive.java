package model;

import java.io.Serializable;

public class Automotive implements Serializable {
	private String name;
	private float baseprice;
	private OptionSet opset[];
	
	// Constructor
	public Automotive() {
	}

	public Automotive (String n, float price, int opsetSize) {
		this.name = n;
		this.baseprice = price;
		this.opset = new OptionSet[opsetSize];
		
		// instantiate object
		for (int i=0; i<this.opset.length; i++){
			this.opset[i] = new OptionSet();
		}
	}

	// Inner class OptionSet
	// Each Automotive contains several OptionSet objects 
	private class OptionSet implements Serializable {
		private String name;
		private Option opt[];
		
		protected OptionSet() {
		}
		
		protected OptionSet(String name, int optSize) {
			this.name = name;
			this.opt = new Option[optSize];
			
			// instantiate object 
			for (int i=0; i<this.opt.length; i++){
				this.opt[i] = new Option();
			}
		}

		protected void setName(String name) {
			this.name = name;
		}
		
		protected String getName() {
			return name;
		}

		protected void setOpt(int index, Option opt) {
			this.opt[index] = opt;
		}
		
		protected Option[] getOpt() {
			return opt;
		}

		protected String print() {
			StringBuffer stringBuffer = new StringBuffer("*" + name + "*" + "\n");
			for (int optIndex=0; optIndex<opt.length; optIndex++){
				stringBuffer.append(opt[optIndex].print() + "\n");
			}
			return stringBuffer.toString();
		}
	}

	// Inner class Option
	// Each OptionSet contains several Option objects
	private class Option implements Serializable {
		private String name;
		float price;
		
		public String getName() {
			return name;
		}
		protected void setName(String name) {
			this.name = name;
		}
		protected float getPrice() {
			return price;
		}
		protected void setPrice(float price) {
			this.price = price;
		}
		
		protected String print() {
			StringBuffer stringBuffer = new StringBuffer(name);
			stringBuffer.append(" - Price: $");
			stringBuffer.append(price);
			return stringBuffer.toString();
		}
	}

	// Getter
	public String getName() {
		return name;
	}
	
	public float getBaseprice() {
		return baseprice;
	}
	
	public OptionSet getOpset(int index) {
		return opset[index];
	}
	
	// Find
	public OptionSet findOpsetWithName(String opsetName) {
		int index = -1;
		for (int i=0; i< opset.length; i++){
			if (opset[i].getName().equals(opsetName)){
				index = i;
				break;
			}
		}
		return opset[index];
	}
	
	public Option findOptWithName(String optName) {
		int opsetIndex = -1;
		int optIndex = -1;
		
		for (int i=0; i< opset.length; i++){
			for (int j=0; j<opset[i].getOpt().length; j++) {
				if (opset[i].getOpt()[j].getName().equals(optName)) {
					opsetIndex = i;
					optIndex = j;
					break;
				}
			}

		}
		return opset[opsetIndex].getOpt()[optIndex];
	}

	// Setter
	public void setName(String name) {
		this.name = name;
	}

	public void setBaseprice(float baseprice) {
		this.baseprice = baseprice;
	}

	public void setOpsetValues(int index, String opsetName, int optSize) {
		OptionSet opset = new OptionSet(opsetName, optSize);
		opset.setName(opsetName);
		this.opset[index] = opset;
	}
	
	public void setOptValues(int opsetIndex, int optIndex, String name, float price) {
		Option opt = new Option();
		opt.setName(name);
		opt.setPrice(price);
		this.opset[opsetIndex].setOpt(optIndex, opt);
	}
	
	// Update
	public void updateOpsetValues(String opsetName, OptionSet opset) {
		for (int i=0; i<this.opset.length; i++){
			if (this.opset[i].getName().equals(opsetName)){
				this.opset[i] = opset;
				break;
			}
		}
	}
	
	public void updateOptValues(String opsetName, String optName, float price) {
		for (int i=0; i<this.opset.length; i++) {
			if (this.opset[i].getName() == opsetName){
				for (int j=0; j<this.opset[i].getOpt().length; j++) {
					if (this.opset[i].getOpt()[j].getName() == optName) {
						this.opset[i].getOpt()[j].setPrice(price);
						break;
					}
				}
			}
		}
	}
	
	// Delete
	public void deleteOpset(String opsetName) {
		for (int i=0; i<this.opset.length; i++) {
			if (this.opset[i].getName().equals(opsetName)) {
				this.opset[i] = null;
				break;
			}
		}
	}
	
	public void deleteOpt(String opsetName, String optName) {
		for (int i=0; i<this.opset.length; i++) {
			if (this.opset[i].getName().equals(opsetName)) {
				for (int j=0; j<this.opset[i].getOpt().length; j++) {
					if (this.opset[i].getOpt()[j].getName().equals(optName)) {
						this.opset[i].getOpt()[j] = null;
						break;
					}
				}
			}
		}
	}
	
	// Print automobile name, base price and options
	public String print() {
		StringBuffer stringBuffer = new StringBuffer("Model Name: ");
		stringBuffer.append(name + "\n");
		stringBuffer.append("Base Price: $");
		stringBuffer.append(baseprice + "\n" + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		
		for (int opsetIndex=0; opsetIndex<opset.length; opsetIndex++) {
			stringBuffer.append("\n");
			stringBuffer.append(opset[opsetIndex].print() + "\n" + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		}
		stringBuffer.append("\n");
		return stringBuffer.toString();
	}
}
