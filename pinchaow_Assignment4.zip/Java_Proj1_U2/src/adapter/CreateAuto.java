package adapter;

public interface CreateAuto {
	void buildAuto(String modelName, String fileName);
	void printAuto(String modelName);
}
