package database;

import model.Automobile;

public interface OperateDB {
	void createAutoDB(Automobile auto);
	void deleteAutoDB(String modelName);
	void updateOptPriceDB(String modelName, String opsetName, String optName, float newPrice);
}
