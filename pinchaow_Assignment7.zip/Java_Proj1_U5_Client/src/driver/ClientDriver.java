//Name: Pinchaow
//Andrew ID: pinchaow
package driver;

import java.io.FileNotFoundException;
import java.io.IOException;

public class ClientDriver {
	public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException{
		
		/**
		 * Unit3: Test for Multi-Threading
		 * 
		 */
		//Driver_U3 driver_u3 = new Driver_U3();
		//driver_u3.startTest();
		
		/**
		 * Unit4 & 5: Socket communication - client side
		 * Enable server-client socket connection
		 */
		Driver_U4 driver_u4 = new Driver_U4();
		driver_u4.startTest();
		
	}
}